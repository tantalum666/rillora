#!/bin/sh
set -eu
if codex mcp get rillora >/dev/null 2>&1; then
  echo 'A Rillora entry already exists. Review it before making any change.' >&2
  exit 1
fi
codex mcp add rillora --url 'https://app.rillora.xyz/api/mcp' --oauth-client-id 'rillora-codex-v1'
